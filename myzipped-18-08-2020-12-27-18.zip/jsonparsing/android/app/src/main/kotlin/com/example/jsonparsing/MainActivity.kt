package com.example.jsonparsing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
